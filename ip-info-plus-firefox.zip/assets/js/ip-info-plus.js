/*
* IP Info Plus
* Developer: Mr Abir Ahamed
* Website: https://www.mishusoft.com
* Official Link: https://hktools.mishusoft.com/extension/ip-info-plus
* Git:https://www.github.com/mrabirahamed/capture-images
* */
'use strict';

function element(id){
    if (document.getElementById(id) !== null){
        return document.getElementById(id);
    }
}

function createElement(node_data) {
    let element, i, j, k;
    for (i in node_data) {
        let data = node_data[i];
        for (j in data) {
            let element_name = j;
            let element_data = data[j];
            element = document.createElement(element_name);
            for (k in element_data) {
                let element_attribute = k;
                let element_attribute_value = element_data[k];
                element.setAttribute(element_attribute, element_attribute_value);
            }
        }
    }
    return element;
}

let ipd = element('ipd-address');
let ipb = element('ipd-search-btn');
let ipl = element('ip-info-plus-app-bottom');
let ipt = element('ip-info-plus-data-table');

function IsJsonString(str) {
    try {
        JSON.parse(str);
    } catch (e) {
        return false;
    }
    return true;
}

function fetchIPDataFile(url, callback) {
    let request = new XMLHttpRequest();
    request.open('GET', url, true);
    request.setRequestHeader('Accept', 'application/json');
    request.onreadystatechange = function () {
        if (this.readyState === 4 && this.status === 200) {
            if (IsJsonString(this.responseText)) {
                let data = JSON.parse(this.responseText);
                if (callback) {
                    callback(data)
                }
            } else {
                alert('Service isn\'t available');
            }
        }
    }
    request.send();
}


function getIPInfo() {
    ipd.style = 'width:59% !important;';
    ipb.value = 'Getting data..';
    ipl.textContent = 'Loading...';
    ipt.setAttribute('style', 'display:none;');
    fetchIPDataFile('https://api.ipdata.co/' + ipd.value + '?api-key=test', function (data) {
        ipd.style = 'width:71% !important;';
        ipb.value = 'Search';
        element('ip-info-plus-data-table').removeAttribute('style');
        ipl.textContent = 'IP INFORMATION:';
        element('ipd-address').value = data.ip;
        element('client-ip').textContent = data.ip;
        element('client-visual-location').href = 'https://www.google.com/maps/@'+ data.latitude +','+ data.longitude +',19z';
        element('client-city').textContent = data.city;
        element('client-region').textContent = data.region;
        element('client-country').textContent = data.country_name + ' ('+ data.country_code + ') ';
        let country_flag = createElement([{'img' : {'style' : 'width: 10px;height: 8px;', 'src' : data.flag, 'alt':'FLAG'}}]);
        element('client-country').appendChild(country_flag);
        element('client-continent-name').textContent = data.continent_name + ' (' + data.continent_code+ ')';
        console.log(element('client-continent-name'));
        element('client-post').textContent = data.postal;
        element('client-asn-name').href = 'https://'+ data.asn.domain;
        element('client-asn-name').textContent = data.asn.name + ' [' + data.asn.type + ']';
        let lng = '';
        for (let n in data.languages){
            lng += data.languages[n].name + '[' + data.languages[n].native +  ']; ';
        }
        element('client-language').textContent = lng;
        element('client-currency-name').textContent = data.currency.name;
        element('client-currency-code').textContent = data.currency.code;
        element('client-currency-symbol').textContent = data.currency.symbol;
        element('client-time-zone-name').textContent = data.time_zone.name;
        element('client-time-zone-abbr').textContent = data.time_zone.abbr;
        element('client-time-zone-offset').textContent = data.time_zone.offset;
        element('client-time-zone-is-dist').textContent = data.time_zone.is_dst;
        element('client-time-zone-current-time').textContent = data.time_zone.current_time;
    });
}


getIPInfo();
ipd.addEventListener('change', getIPInfo, false);
ipb.addEventListener('click', getIPInfo, false);

document.addEventListener("contextmenu", function (e) {
    e.preventDefault();
}, false);
